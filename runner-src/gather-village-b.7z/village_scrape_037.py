import csv
from bs4 import BeautifulSoup  # also install 'lxml' cos you parse with it
# import lxml
import logging
import concurrent.futures
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
import sys
import time
import supermartfunc
from supermart_utils.village_scraper_035 import (load_cat_urls_from_file, get_page_soup, find_out_last_page,
                                                 generate_next_pages, extract_products)

# categories_file = "village-categories.txt"
scraper_output_file = "C:/Users/Lemming/Desktop/output/supermarts/village-scraper-cf.csv"
base_url = "https://vgg.bites.com.my/"
csv_list = [['Start URL', 'Category', 'Product', 'Price', 'Slash Price', 'Details Link']]
# needs a list of lists, aka nested lists
# next_pages_list = []
page_pause_delay = 0.51
page_retry_delay = 2.38
break_time_delay = 5.29
page_counter = 1
page_pause_tuple = (15, 24, 33, 47, 60, 76, 96)
delay_is_on = False

# Define the maximum number of retries and backoff factor
max_retries = 3
backoff_factor = 0.3

# from https://curlconverter.com/
cookies = {
    '_orig_referrer': 'https%3A%2F%2Fvillagegrocer.com.my%2F',
    '_landing_page': '%2F',
    'localization': 'MY',
    'postcode': '47400',
    'collection-method-delivery': '1',
    'show-postcode-popup': '0'
}

user_agent = \
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36'
sec_ch_ua = '"Not A(Brand";v="24", "Chromium";v="137", "Google Chrome";v="137"'

# noinspection PyDictCreation
headers = {
    'authority': 'vgg.bites.com.my',
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'priority': 'u=1, i',
    'referer': 'https://vgg.bites.com.my',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"', 'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'x-requested-with': 'XMLHttpRequest'
}

headers['sec-ch-ua'] = sec_ch_ua
headers['user-agent'] = user_agent

# def load_cat_urls_from_file():
# def find_out_last_page(input_body_soup):
# def generate_next_pages(input_category, input_category_url, input_last_page):

# --- Configuration for logging ---
LOG_FILE = "village_error_log.txt"
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.ERROR,  # Only log messages with severity ERROR or higher
    format='%(asctime)s - %(levelname)s - %(message)s'
)
# --- End logging configuration ---


def get_page_soup_cookies(url):
    response = None
    for attempt in range(1, 3):  # only retry once; this counts to 2
        try:
            response = session.get(url, cookies=cookies,
                                   headers=headers, timeout=8, stream=False)
            # timeout best practise, https://realpython.com/python-requests/
            # stream=False cos I didn't explicitly close the responses, so they were keeping the socket open,
            # and the python process ran out of file handles.
            response.raise_for_status()
        except requests.exceptions.ReadTimeout:
            if attempt == 1:  # Retry only on the first attempt
                print(f"ReadTimeout occurred, retrying in {page_retry_delay}...")
                time.sleep(page_retry_delay)
            else:
                print(f"Error: Connection to {url} timed out after {attempt + 1} attempts.")
                raise  # Re-raise the exception after retries
        except requests.exceptions.RequestException as reqe:
            print(f"Error: {reqe}")
            return False

    if response:
        curr_soup = BeautifulSoup(response.content, 'lxml')  # instead of html.parser
        # print(curr_soup)
        return curr_soup
    else:
        return False


# def get_page_soup(url):


def category_page_one_func(input_cat_url):
    curr_next_pages_list = []
    cat_pg1_tuple = process_category_page_one(input_cat_url)
    category = cat_pg1_tuple[0]
    # print("Category from tuple", category)
    cat_soup_body = cat_pg1_tuple[1]
    time.sleep(0.83)
    last_page = find_out_last_page(cat_soup_body)
    if last_page > 0:
        curr_next_pages_list = generate_next_pages(category, input_cat_url, last_page)
        # next_pages_list.extend(curr_next_pages_list)  # extend, not append
        # process_cat_other_pages(next_pages_list, category)
    return curr_next_pages_list


def process_category_page_one(input_cat_url):
    cat_soup = get_page_soup_cookies(input_cat_url)
    cat_head_content = cat_soup.head
    cat_body_content = cat_soup.body
    # find out category
    if cat_head_content:
        category_soup = cat_head_content.select_one("head meta[property='og:title']")
        if category_soup:
            category = str(category_soup['content']).strip()
        else:
            category = "Unknown"
    else:
        category = "Unknown"
    print("Current category is", category)

    if cat_body_content:
        print("-- Current page:", input_cat_url)
        curr_page_list_of_row_lists_b = extract_products(cat_body_content, category, input_cat_url)
    else:
        print("No <body> element found.")
        curr_page_list_of_row_lists_b = []

    csv_list.extend(curr_page_list_of_row_lists_b)  # extend, not append list

    cat_page_one_tuple = (category, cat_body_content)
    return cat_page_one_tuple


def process_cat_other_pages(input_cat_other_pages_tuple):
    global page_counter
    global delay_is_on
    category = input_cat_other_pages_tuple[0]
    curr_page_url = input_cat_other_pages_tuple[1]
    print("-- Current page:", curr_page_url)
    page_counter += 1
    soup = get_page_soup(curr_page_url)
    body_content = soup.body
    if body_content:
        curr_page_list_of_row_lists = extract_products(body_content, category, curr_page_url)
        time.sleep(0.53)
    else:
        print("No <body> element found.")
        curr_page_list_of_row_lists = []
    # csv_list.extend(curr_page_list_of_row_lists)
    if page_counter in page_pause_tuple and delay_is_on is False:   # == 15 or page_counter == 30:
        print("Page", page_counter, ", pausing ", break_time_delay, "sec")
        delay_is_on = True
        time.sleep(break_time_delay)
        delay_is_on = False
    return curr_page_list_of_row_lists


# def extract_products(body_content_soup, input_category, input_category_url):


def main():
    timer_start = time.perf_counter()
    next_pages_list = []

    if not supermartfunc.is_connected():
        print("No internet connectivity. Exiting.")
        sys.exit(1)
    print("Internet connection is OK. Continuing...")

    category_urls = load_cat_urls_from_file()

    # build lists of next pages
    # with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
    #     cat_next_pages = executor.map(category_page_one_func, category_urls)
    for curr_category_urls in category_urls:
        curr_next_pages_list = category_page_one_func(curr_category_urls)
        time.sleep(page_pause_delay)
        next_pages_list.extend(curr_next_pages_list)  # extend, not append

    # print(next_pages_list)
    time.sleep(2.53)
    print("Slight pause...")

    # with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
    with concurrent.futures.ProcessPoolExecutor(max_workers=2) as executor:
        futures = []
        for curr_url in next_pages_list:
            futures.append(executor.submit(process_cat_other_pages, curr_url))
            time.sleep(page_pause_delay)

        for future in concurrent.futures.as_completed(futures):
            curr_page_list = future.result()
            csv_list.extend(curr_page_list)

    with open(scraper_output_file, 'w', encoding='utf-8', newline='') as file:
        writer = csv.writer(file)
        writer.writerows(csv_list)

    print("Output file:", scraper_output_file)
    print("Got", len(csv_list) - 1, "items")  # minus the headers
    timer_end = time.perf_counter()

    elapsed = timer_end - timer_start

    if elapsed >= 60:
        minutes, seconds = divmod(elapsed, 60)
        print(f"{minutes:.0f} min, {seconds:.2f} sec")
    else:
        print(f"{elapsed:.2f} sec")
    print(time.ctime())


retries = Retry(total=max_retries, backoff_factor=backoff_factor,
                status_forcelist=[429, 500, 502, 503, 504])
session = requests.Session()
adapter = HTTPAdapter(max_retries=retries)
session.mount('http://', adapter)
session.mount('https://', adapter)
if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"A critical error occurred in main execution: {e}")
        logging.critical(f"A critical error occurred in main execution: {e}", exc_info=True)
    finally:
        # closing the connection
        session.close()
        print("Session closed.")
